#if (!requireNamespace("BiocManager", quietly = TRUE))
#    install.packages("BiocManager")
#BiocManager::install("limma")

#install.packages("ggplot2")
#install.packages("ggpubr")


#Reference package
library(limma)
library(ggplot2)
library(ggpubr)

pFilter=0.001                      #p value
riskFile="risk.txt"            
drugFile="DrugPredictions.csv"     
setwd("  ")     #Set working directory


risk=read.table(riskFile, header=T, sep="\t", check.names=F, row.names=1)


senstivity=read.csv(drugFile, header=T, sep=",", check.names=F, row.names=1)
colnames(senstivity)=gsub("(.*)\\_(\\d+)", "\\1", colnames(senstivity))

#Merge data
sameSample=intersect(row.names(risk), row.names(senstivity))
risk=risk[sameSample, "risk",drop=F]
senstivity=senstivity[sameSample,,drop=F]
rt=cbind(risk, senstivity)

rt$risk=factor(rt$risk, levels=c("low", "high"))
type=levels(factor(rt[,"risk"]))
comp=combn(type, 2)
my_comparisons=list()
for(i in 1:ncol(comp)){my_comparisons[[i]]<-comp[,i]}

for(drug in colnames(rt)[2:ncol(rt)]){
	rt1=rt[,c(drug, "risk")]
	colnames(rt1)=c("Drug", "Risk")
	rt1=na.omit(rt1)
	rt1$Drug=log2(rt1$Drug+1)
	#Difference analysis
	test=wilcox.test(Drug ~ Risk, data=rt1)
	diffPvalue=test$p.value
	#Boxplot of drugs that meet the conditions
	if(diffPvalue<pFilter){
		boxplot=ggboxplot(rt1, x="Risk", y="Drug", fill="Risk",
					      xlab="Risk",
					      ylab=paste0(drug, " senstivity"),
					      legend.title="Risk",
					      palette=c("#0066FF","#FF0000")
					     )+ 
			stat_compare_means(comparisons=my_comparisons)
		#Output figure
		pdf(file=paste0("drugSenstivity.", drug, ".pdf"), width=5, height=4.5)
		print(boxplot)
		dev.off()
	}
}

