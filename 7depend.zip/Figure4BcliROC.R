

#install.packages("survival")
#install.packages("survminer")
#install.packages("timeROC")


#Reference package
library(survival)
library(survminer)
library(timeROC)
riskFile="TCGArisk.txt"         #Input risk file
cliFile="clinical.txt"      #Clinical file
setwd("  ")     #Set working directory

#Read risk file
risk=read.table(riskFile, header=T, sep="\t", check.names=F, row.names=1)
risk=risk[,c("futime", "fustat", "riskScore")]

#Read clinical file
cli=read.table(cliFile, header=T, sep="\t", check.names=F, row.names=1)

#Merge data
samSample=intersect(row.names(risk), row.names(cli))
risk1=risk[samSample,,drop=F]
cli=cli[samSample,,drop=F]
rt=cbind(risk1, cli)

#Colour
bioCol=rainbow(ncol(rt)-1, s=0.9, v=0.9)



predictTime=1     
aucText=c()
pdf(file="cliROC.pdf", width=6, height=6)

i=3
ROC_rt=timeROC(T=risk$futime,
               delta=risk$fustat,
               marker=risk$riskScore, cause=1,
               weighting='aalen',
               times=c(predictTime),ROC=TRUE)
plot(ROC_rt, time=predictTime, col=bioCol[i-2], title=FALSE, lwd=2)
aucText=c(paste0("Risk", ", AUC=", sprintf("%.3f",ROC_rt$AUC[2])))
abline(0,1)
#ROC curve
for(i in 4:ncol(rt)){
	ROC_rt=timeROC(T=rt$futime,
				   delta=rt$fustat,
				   marker=rt[,i], cause=1,
				   weighting='aalen',
				   times=c(predictTime),ROC=TRUE)
	plot(ROC_rt, time=predictTime, col=bioCol[i-2], title=FALSE, lwd=2, add=TRUE)
	aucText=c(aucText, paste0(colnames(rt)[i],", AUC=",sprintf("%.3f",ROC_rt$AUC[2])))
}
#AUC value
legend("bottomright", aucText,lwd=2,bty="n",col=bioCol[1:(ncol(rt)-1)])
dev.off()

